package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class Loginpage {

	public static WebDriver driver;

	public Loginpage(WebDriver idriver) {
		this.driver = idriver;

	}

	@FindBy(how = How.XPATH, using = "//img[@class='jss23']")
	@CacheLookup
	private WebElement logo;

	@FindBy(how = How.XPATH, using = "//input[@id='emailAddress']")
	@CacheLookup
	private WebElement userid;

	@FindBy(how = How.XPATH, using = "//input[@id='password']")
	@CacheLookup
	private WebElement pswrd;

	@FindBy(how = How.XPATH, using = "//h6[normalize-space()='SIGN_IN_BUTTON']")
	@CacheLookup
	private WebElement signbtn;

	@FindBy(how = How.XPATH, using = "//a[normalize-space()='FORGOTTEN_PASSWORD_LINK']")
	@CacheLookup
	private WebElement frgtPwd;

	public void login(String uid, String pwd) {

		userid.sendKeys(uid);
		pswrd.sendKeys(pwd);
		signbtn.click();
	}

}
