package pages;

public class Dashboard {

}
