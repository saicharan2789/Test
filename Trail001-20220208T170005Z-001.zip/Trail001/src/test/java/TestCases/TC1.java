package TestCases;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import pages.*;
import utilities.*;

public class TC1 {

	WebDriver driver;

	@org.testng.annotations.Test
	public void logintest() {

		try {
			WebDriver driver = BrowserLaunch.startBrowser("Chrome", "https://reference-test.intellisense.io/");
		} catch (Exception e) {
			e.printStackTrace();
		}

		Loginpage loginpge = PageFactory.initElements(driver, Loginpage.class);
		/*
		 * Loginpage page = new Loginpage(driver); PageFactory.initElements(driver,
		 * page);
		 */
		// Loginpage loginpge = PageFactory.initElements(driver, Loginpage.class);
		loginpge.login("menna+testproject@intellisense.io", "AutMaNewTest1#");

	}

}
