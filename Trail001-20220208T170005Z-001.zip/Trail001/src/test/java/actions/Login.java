/**
 * 
 */
package actions;

import pages.*;

import org.openqa.selenium.WebDriver;

/**
 * @author sunka
 *
 */
public class Login  {
	
	WebDriver driver;
	public void loginpage() {
		
		
	}

}
